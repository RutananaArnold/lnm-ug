<?php echo $_SERVER['DOCUMENT_ROOT']; ?>

<!-- uploaden und ausf�hren, um kompletten Pfad zu erhalten -->